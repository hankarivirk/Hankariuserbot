from telethon.sessions import StringSession
from telethon.sync import TelegramClient
from telethon.errors import SessionPasswordNeededError
from telethon.tl.functions.messages import SendMessageRequest
from config import API_ID, API_HASH
from utils.auth import login_user

from telethon import events

# This function adds a command handler to the bot
def add_login_handler(bot):

    @bot.on(events.NewMessage(pattern='/login'))
    async def handler(event):
        user = await event.get_sender()
        user_id = user.id

        await event.respond("📞 Send your phone number with country code (e.g., +911234567890):")

        def phone_check(e):
            return e.sender_id == user_id

        phone_event = await bot.wait_for(events.NewMessage(from_users=user_id))
        phone = phone_event.raw_text.strip()

        await event.respond("🔐 If you have 2FA password, send it now. If not, send `none`:")        
        password_event = await bot.wait_for(events.NewMessage(from_users=user_id))
        password_text = password_event.raw_text.strip()

        password = None if password_text.lower() == "none" else password_text

        await event.respond("⏳ Logging you in, please wait...")

        try:
            session_str = await login_user(phone, password)
            await event.respond("✅ Session generated and sent to your Saved Messages.")
        except Exception as e:
            await event.respond(f"❌ Login failed: {e}")