from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from config import API_ID, API_HASH

async def send_session_to_saved_messages(session_str, user_id):
    client = TelegramClient(StringSession(session_str), API_ID, API_HASH)
    await client.start()
    
    message = (
        "✅ **Your Telethon Session Has Been Generated Successfully!**\n\n"
        f"`{session_str}`\n\n"
        "🔐 Keep it secure. Do not share this with anyone."
    )

    await client.send_message("me", message, parse_mode="markdown")
    await client.disconnect()