from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError
from config import API_ID, API_HASH
from utils.save_session import send_session_to_saved_messages

async def login_user(phone_number, password=None):
    session = StringSession()
    client = TelegramClient(session, API_ID, API_HASH)

    await client.connect()
    if not await client.is_user_authorized():
        try:
            await client.send_code_request(phone_number)
            code = input(f"📨 Enter the code sent to {phone_number}: ")

            await client.sign_in(phone_number, code)

        except SessionPasswordNeededError:
            if password is None:
                password = input("🔐 Enter your 2FA password: ")
            await client.sign_in(password=password)

    session_str = client.session.save()
    me = await client.get_me()
    user_id = me.id

    await send_session_to_saved_messages(session_str, user_id)
    await client.disconnect()

    return session_str