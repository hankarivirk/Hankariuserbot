from telegram import Update, ForceReply
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler
from utils.auth import handle_login
from config import BOT_TOKEN, OWNER_USERNAME

ASK_PHONE, ASK_PASSWORD = range(2)
user_inputs = {}

# /start command
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Welcome to Hankari Userbot!\n\nUse /login to log in with your phone number.")

# /login flow
async def login_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("📱 Please send your phone number (with country code, e.g., +91...).")
    return ASK_PHONE

async def ask_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_inputs[user_id] = {"phone": update.message.text}
    await update.message.reply_text("🔐 If you have 2FA password, send it now. If not, type 'skip'.")
    return ASK_PASSWORD

async def ask_password(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    password = update.message.text
    if password.lower() == "skip":
        password = None
    phone = user_inputs[user_id]["phone"]

    await update.message.reply_text("⏳ Logging in...")

    result = await handle_login(phone, password)

    if result["status"] == "success":
        await update.message.reply_text("✅ Logged in successfully! Session saved.")
    else:
        await update.message.reply_text(f"❌ Login failed: {result['message']}")

    return ConversationHandler.END

# /cancel command
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ Login cancelled.")
    return ConversationHandler.END

# /owner command
async def owner_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"👑 Bot created by: @{OWNER_USERNAME}")

# main
def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("login", login_command)],
        states={
            ASK_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_phone)],
            ASK_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_password)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(conv_handler)
    app.add_handler(CommandHandler("owner", owner_command))

    print("🤖 Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()